<?php
/* Smarty version 3.1.29, created on 2016-11-28 11:32:33
  from "/usr/share/nginx/html/resources/views/default/admin/checkinlog.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_583ba55167a311_09376785',
  'file_dependency' => 
  array (
    '068d4e645fe33e90398dda5e09c745747ca157a7' => 
    array (
      0 => '/usr/share/nginx/html/resources/views/default/admin/checkinlog.tpl',
      1 => 1475290766,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:admin/main.tpl' => 1,
    'file:user/footer.tpl' => 1,
  ),
),false)) {
function content_583ba55167a311_09376785 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:admin/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            流量使用记录
            <small>Traffic Log</small>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body table-responsive no-padding">
                        <?php echo $_smarty_tpl->tpl_vars['logs']->value->render();?>

                        <table class="table table-hover">
                            <tr>
                                <th>ID</th>
                                <th>用户</th>
                                <th>获得流量</th>
                                <th>签到时间</th>
                            </tr>
                            <?php
$_from = $_smarty_tpl->tpl_vars['logs']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_log_0_saved_item = isset($_smarty_tpl->tpl_vars['log']) ? $_smarty_tpl->tpl_vars['log'] : false;
$_smarty_tpl->tpl_vars['log'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['log']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['log']->value) {
$_smarty_tpl->tpl_vars['log']->_loop = true;
$__foreach_log_0_saved_local_item = $_smarty_tpl->tpl_vars['log'];
?>
                                <tr>
                                    <td>#<?php echo $_smarty_tpl->tpl_vars['log']->value->id;?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['log']->value->user_id;?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['log']->value->traffic();?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['log']->value->CheckInTime();?>
</td>
                                </tr>
                            <?php
$_smarty_tpl->tpl_vars['log'] = $__foreach_log_0_saved_local_item;
}
if ($__foreach_log_0_saved_item) {
$_smarty_tpl->tpl_vars['log'] = $__foreach_log_0_saved_item;
}
?>
                        </table>
                        <?php echo $_smarty_tpl->tpl_vars['logs']->value->render();?>

                    </div><!-- /.box-body -->
                </div><!-- /.box -->
            </div>
        </div>

    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:user/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
