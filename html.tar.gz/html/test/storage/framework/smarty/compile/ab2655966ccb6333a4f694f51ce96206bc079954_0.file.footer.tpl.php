<?php
/* Smarty version 3.1.29, created on 2016-10-02 15:37:43
  from "/usr/share/nginx/html/resources/views/default/admin/footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57f0b947380fd8_86533684',
  'file_dependency' => 
  array (
    'ab2655966ccb6333a4f694f51ce96206bc079954' => 
    array (
      0 => '/usr/share/nginx/html/resources/views/default/admin/footer.tpl',
      1 => 1475290766,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57f0b947380fd8_86533684 ($_smarty_tpl) {
?>
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        Made with Love
    </div>
    <strong>Copyright &copy; 2016 <a href="#"><?php echo $_smarty_tpl->tpl_vars['config']->value['appName'];?>
</a> </strong>
    All rights reserved. Powered by <b>ss-panel</b> <?php echo $_smarty_tpl->tpl_vars['config']->value['version'];?>
 | <a href="/tos">服务条款 </a>
</footer>
</div><!-- ./wrapper -->


<!-- Bootstrap 3.3.2 JS -->
<?php echo '<script'; ?>
 src="/assets/public/js/bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!-- SlimScroll -->
<?php echo '<script'; ?>
 src="/assets/public/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!-- FastClick -->
<?php echo '<script'; ?>
 src='/assets/public/plugins/fastclick/fastclick.min.js'><?php echo '</script'; ?>
>
<!-- AdminLTE App -->
<?php echo '<script'; ?>
 src="/assets/public/js/app.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<div style="display:none;">
    <?php echo $_smarty_tpl->tpl_vars['analyticsCode']->value;?>

</div>
</body>
</html>
<?php }
}
