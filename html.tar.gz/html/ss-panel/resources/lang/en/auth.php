<?php

return [

    'login' => 'Login',
    'Register' => 'Register'
];
