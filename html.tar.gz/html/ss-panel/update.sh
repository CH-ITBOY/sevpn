#!/usr/bin/env bash
git pull
composer install