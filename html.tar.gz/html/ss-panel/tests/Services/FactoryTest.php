<?php

namespace Tests\Services;

use App\Services\Factory;
use App\Services\Config;
use App\Services\Auth\Redis;
use Tests\TestCase;

class FactoryTest extends TestCase
{
    public function testAuth(){
    }
}