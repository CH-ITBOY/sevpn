<?php


namespace App\Services\Token;


class Token
{
    public $token,$userId,$createTime,$expireTime;
}